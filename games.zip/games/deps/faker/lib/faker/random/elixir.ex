defmodule Faker.Random.Elixir do
  @moduledoc """
  Default implementation of random functions based on erlang and elixir standard library.
  """

  use Faker.Random
end
