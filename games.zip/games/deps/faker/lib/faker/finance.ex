defmodule Faker.Finance do
  @moduledoc """
  Functions for generating financial data
  """
end
