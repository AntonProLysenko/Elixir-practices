defmodule EarmarkParser.Block.Html do
  @moduledoc false
  defstruct lnb: 0, annotation: nil, attrs: nil, html: [], tag: nil
end
#  SPDX-License-Identifier: Apache-2.0
