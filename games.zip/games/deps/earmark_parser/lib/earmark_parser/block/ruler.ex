defmodule EarmarkParser.Block.Ruler do
  @moduledoc false
  defstruct lnb: 0, annotation: nil, attrs: nil, type: nil
end
#  SPDX-License-Identifier: Apache-2.0
