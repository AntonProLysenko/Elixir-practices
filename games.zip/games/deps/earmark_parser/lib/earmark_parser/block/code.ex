defmodule EarmarkParser.Block.Code do
  @moduledoc false
  defstruct lnb: 0, annotation: nil, attrs: nil, lines: [], language: nil
end
#  SPDX-License-Identifier: Apache-2.0
