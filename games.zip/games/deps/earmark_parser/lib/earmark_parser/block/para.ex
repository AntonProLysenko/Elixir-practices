defmodule EarmarkParser.Block.Para do
  @moduledoc false
  defstruct lnb: 0, annotation: nil, attrs: nil, lines: []
end
#  SPDX-License-Identifier: Apache-2.0
