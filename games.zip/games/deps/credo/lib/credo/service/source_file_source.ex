defmodule Credo.Service.SourceFileSource do
  @moduledoc false

  use Credo.Service.ETSTableHelper
end
